﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Evolent.Infra.Respository
{
    public interface IRepository<TEntity> where TEntity : class
    {
        Task Add(TEntity entity);

        void Remove(TEntity entity);

        void Update(TEntity entity);

        IQueryable<TEntity> GetAll();

        Task<TEntity> GetByIdAsync(object id);

        IQueryable<TEntity> Find(Expression<Func<TEntity, bool>> predicate);
        Task<IEnumerable<TEntity>> GetAllAsync();

        Task<IEnumerable<TEntity>> GetAllAsync<TProperty>(Expression<Func<TEntity, TProperty>> include);


        Task<TEntity> SingleOrDefaultAsync(Expression<Func<TEntity, bool>> predicate);

    }
}
