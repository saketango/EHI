﻿using Evolent.Infra.Respository;
using System;
using System.Collections.Generic;
using System.Text;

namespace Evolent.Infra.UoW
{
    public interface IUnitOfWork : IDisposable
    {
        IRepository<TEntity> GetRepository<TEntity>() where TEntity : class;

        int Commit();
    }
}
