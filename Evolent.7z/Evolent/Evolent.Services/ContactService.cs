﻿using AutoMapper;
using Evolent.Domain.POCO;
using Evolent.Domain.ViewModel;
using Evolent.Infra.UoW;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Evolent.Services
{
    /// <summary>
    /// Service Class for Contact
    /// </summary>
    public class ContactService : IContactService
    {
        IUnitOfWork _unitofWork;
        IMapper _mapper;
        public ContactService(IUnitOfWork unitofWork, IMapper mapper)
        {
            _unitofWork = unitofWork;
            _mapper = mapper;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="contactVM"></param>
        /// <returns></returns>
        public async Task CreateContact(ContactVM contactVM)
        {
            try
            {
                Contact contact;
                contact = _mapper.Map<Contact>(contactVM);
                await _unitofWork.GetRepository<Contact>().Add(contact);
                _unitofWork.Commit();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="contactId"></param>
        public void DeActivateContact(int contactId)
        {
            try
            {
                var _contact = _unitofWork.GetRepository<Contact>().Find(x => x.ContactId == contactId).AsNoTracking().FirstOrDefault();
                _contact.Status = false;
                _unitofWork.GetRepository<Contact>().Update(_contact);
                _unitofWork.Commit();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public Task<List<ContactVM>> GetContacts()
        {
            try
            {
                var result = _unitofWork.GetRepository<Contact>().GetAll().Where(x => x.Status == true).ToList();
                var mapperObject = _mapper.Map<List<ContactVM>>(result);
                return Task.FromResult(mapperObject);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="contactVM"></param>
        public void UpdateContact(ContactVM contactVM)
        {
            try
            {
                Contact contact;
                contact = _mapper.Map<Contact>(contactVM);
                var _contact = _unitofWork.GetRepository<Contact>().Find(x => x.ContactId == contact.ContactId).AsNoTracking().FirstOrDefault();
                _unitofWork.GetRepository<Contact>().Update(contact);
                _unitofWork.Commit();
            }
            catch
            {
                throw;
            }
        }
    }
}
