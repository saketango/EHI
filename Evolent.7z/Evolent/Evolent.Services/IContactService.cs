﻿using Evolent.Domain.ViewModel;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Evolent.Services
{
    public interface IContactService
    {
        Task CreateContact(ContactVM contact);

        void UpdateContact(ContactVM contact);

        Task<List<ContactVM>> GetContacts();

        void DeActivateContact(int contactId);
    }
}
