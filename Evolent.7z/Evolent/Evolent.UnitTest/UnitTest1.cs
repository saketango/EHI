using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Evolent.UnitTest
{
    public class TestContactService
    {
        private Mock<IUnitOfWork> _uow;
        private List<Contact> _contactList;

        [SetUp]
        public void Setup()
        {
            _uow = new Mock<IUnitOfWork>();
            _contactList = new List<Contact>{
                new Contact { ContactId = 1, FirstName = "Bhushan", LastName = "Patil", Email = "bhushan@gmail.com", PhoneNumber = "123456", Status = true },
                new Contact { ContactId = 1, FirstName = "Tushar", LastName = "Patil", Email = "tushar@gmail.com", PhoneNumber = "1234560", Status = true },
                new Contact { ContactId = 1, FirstName = "Abhay", LastName = "Patil", Email = "abhay@gmail.com", PhoneNumber = "1234561", Status = false }
                };
        }

        [Test]
        public void Test_GetAll_ActiveContacts()
        {
            _uow.Setup(t => t.GetRepository<Contact>().GetAll()).Returns(_contactList.AsQueryable());

            var contactService = new ContactService(_uow.Object);
            var contactList = contactService.GetContacts();

            Assert.IsTrue(contactList.Count() == 2);
            Assert.IsTrue(contactList.All(c => c.Status == true));
        }
    }
}
