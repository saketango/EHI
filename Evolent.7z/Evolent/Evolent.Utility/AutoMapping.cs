﻿using AutoMapper;
using Evolent.Domain.POCO;
using Evolent.Domain.ViewModel;
using System;

namespace Evolent.Utility
{
    /// <summary>
    /// This calss is used for types mapping
    /// </summary>
    public class AutoMapping : Profile
    {
        public AutoMapping()
        {
            CreateMap<Contact, ContactVM>();
            CreateMap<ContactVM, Contact>();
        }
    }
}
