﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Text;

namespace Evolent.Utility
{
    /// <summary>
    /// Setting up of configuration Env wise
    /// </summary>
    public static class ConnectionService
    {
        public static string ehiConnectionString = string.Empty;
        public static string _environment = string.Empty;

        public static void Set(IConfiguration config)
        {
            ehiConnectionString = config.GetConnectionString("ehiConnectionString");
            _environment = config.GetSection("Environment").Value;
        }
    }
}
