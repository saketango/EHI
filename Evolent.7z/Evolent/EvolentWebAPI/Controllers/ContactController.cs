﻿using Evolent.Domain.ViewModel;
using Evolent.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace EvolentWebAPI.Controllers
{
    /// <summary>
    /// Contoller for Contact CRUD
    /// </summary>
    [ApiController]
    [Route("[controller]")]
    public class ContactController : Controller
    {
        private IContactService contactService;
        public ContactController(IContactService contactService)
        {
            this.contactService = contactService;
        }

        /// <summary>
        /// async GetConstact
        /// </summary>
        /// <returns></returns>
        [Route("GetContacts")]
        [HttpGet]
        public async Task<IActionResult> GetContacts()
        {
            try
            {
                var contact = await contactService.GetContacts();
                return Ok(contact);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "Error Occurred", success = false });
            }
        }

        /// <summary>
        /// async Save
        /// </summary>
        /// <param name="contact"></param>
        /// <returns></returns>
        [Route("CreateContact")]
        [HttpPost]
        public async Task<IActionResult> CreateContact(ContactVM contact)
        {
            try
            {
                await contactService.CreateContact(contact);
                return Ok(new { message = "Data Inserted", success = true });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "Error Occurred", success = false });
            }
        }

        [Route("UpdateContact")]
        [HttpPut]
        public IActionResult UpdateContact(ContactVM contact)
        {
            try
            {
                contactService.UpdateContact(contact);
                return Ok(new { message = "Data Updated", success = true });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "Error Occurred", success = false });
            }
        }

        [Route("DeActivateContact/{id}")]
        [HttpPut]
        public ActionResult DeActivateContact(int id)
        {
            try
            {
                contactService.DeActivateContact(id);
                return Ok(new { message = "Data DeActivated", success = true });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "Error Occurred", success = false });
            }
        }
    }
}
